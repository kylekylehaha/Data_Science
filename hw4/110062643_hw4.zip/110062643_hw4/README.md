# HW4 
## Python version
- Python 3.10.4

---

## Package
- numpy
- scipy
- numba
- genism
- deeprobust
    - how to install? 
    ```
    git clone https://github.com/DSE-MSU/DeepRobust.git
    cd DeepRobust
    python setup.py install
    ```